
//startup callbacks
window.onload = function(ev) {
    startupPopup();
    setSkillCardsIcons();

    //
    compile_elements();

    //
    mobileDiscrimination();
};